replace spam by imdb text data
make sure there are notebooks for all sections
make sure there are exercises everywhere
